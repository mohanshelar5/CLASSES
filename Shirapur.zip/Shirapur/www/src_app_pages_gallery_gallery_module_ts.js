"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_gallery_gallery_module_ts"],{

/***/ 2538:
/*!***********************************************************************************************************************************************************!*\
  !*** ./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/gallery/gallery.page.html ***!
  \***********************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>वाढदिवस</ion-title>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n  <!-- (click)=\"openKutumbaDetails(item.fields.parent_id,item.fields.vasti_name)\" -->\n  <ion-card *ngFor=\"let item of todoList\" class=\"ion-margin\" >\n  <ion-card-header>\n  \n  <ion-item>\n    <ion-icon name=\"ellipse\"></ion-icon>\n    <ion-label> <img [src]=\"baseURL+item.fields.photo\"><br>{{item.fields.name}}</ion-label>\n  </ion-item>\n  </ion-card-header>\n  <!-- <ion-card-content>\n    <ion-label>Due {{item.itemName}}</ion-label>\n  </ion-card-content> -->\n  <ion-row>\n    <ion-item>\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>जन्मतारीख : {{item.fields.birth_date}}</p>\n    </ion-item>\n    <ion-item>\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>गाव : शिरापूर</p>\n    </ion-item>\n    <ion-item href=\"https://wa.me/91 {{item.fields.phone_no}} India?text=Happy Birthday {{item.fields.name}}\">\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>मोबाईल नंबर : {{item.fields.phone_no}}</p>\n    </ion-item>\n  </ion-row>\n\n  </ion-card>\n</ion-content>\n");

/***/ }),

/***/ 3297:
/*!*************************************************!*\
  !*** ./src/app/pages/gallery/gallery.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GalleryPageModule": () => (/* binding */ GalleryPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 8058);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _gallery_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./gallery.page */ 91);







let GalleryPageModule = class GalleryPageModule {
};
GalleryPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild([{ path: '', component: _gallery_page__WEBPACK_IMPORTED_MODULE_0__.GalleryPage }])
        ],
        declarations: [_gallery_page__WEBPACK_IMPORTED_MODULE_0__.GalleryPage]
    })
], GalleryPageModule);



/***/ }),

/***/ 91:
/*!***********************************************!*\
  !*** ./src/app/pages/gallery/gallery.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GalleryPage": () => (/* binding */ GalleryPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_gallery_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./gallery.page.html */ 2538);
/* harmony import */ var _gallery_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./gallery.page.scss */ 8153);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var src_app_providers_conference_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/conference-data */ 4700);
/* harmony import */ var _services_photo_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/photo.service */ 8689);







let GalleryPage = class GalleryPage {
    constructor(photoService, data, router) {
        this.photoService = photoService;
        this.data = data;
        this.router = router;
        this.todoList = [];
        this.baseURL = "https://shirapur.pythonanywhere.com/media/";
    }
    ngOnInit() {
        this.todoList = [];
        const formData = new FormData();
        formData.set('token', window.localStorage.getItem("Token"));
        this.data.post("/api/birthdays/", formData).subscribe(data => {
            this.todoList = JSON.parse(data.birth_day_today);
            console.log(data);
        });
    }
    openKutumbaDetails(kutumbId, vasti) {
        //this.router.navigateByUrl('/app/tabs/kutumba-details');
        debugger;
        this.router.navigate(['/app/tabs/kutumba-details'], { state: { kutumbId: kutumbId, vasti: vasti } });
    }
};
GalleryPage.ctorParameters = () => [
    { type: _services_photo_service__WEBPACK_IMPORTED_MODULE_3__.PhotoService },
    { type: src_app_providers_conference_data__WEBPACK_IMPORTED_MODULE_2__.ConferenceData },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router }
];
GalleryPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-gallery',
        template: _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_gallery_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_gallery_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], GalleryPage);



/***/ }),

/***/ 8689:
/*!*******************************************!*\
  !*** ./src/app/services/photo.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PhotoService": () => (/* binding */ PhotoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _awesome_cordova_plugins_camera_ngx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @awesome-cordova-plugins/camera/ngx */ 7341);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/storage */ 6151);




let PhotoService = class PhotoService {
    constructor(camera, storage) {
        this.camera = camera;
        this.storage = storage;
        this.photos = [];
    }
    takePicture() {
        const options = {
            quality: 100,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        };
        this.camera.getPicture(options).then((imageData) => {
            // Add new photo to gallery
            this.photos.unshift({
                data: 'data:image/jpeg;base64,' + imageData
            });
            // Save all photos for later viewing
            this.storage.set('photos', this.photos);
        }, (err) => {
            // Handle error
            console.log("Camera issue: " + err);
        });
    }
    loadSaved() {
        this.storage.get('photos').then((photos) => {
            this.photos = photos || [];
        });
    }
};
PhotoService.ctorParameters = () => [
    { type: _awesome_cordova_plugins_camera_ngx__WEBPACK_IMPORTED_MODULE_0__.Camera },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_1__.Storage }
];
PhotoService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], PhotoService);

class Photo {
}


/***/ }),

/***/ 8153:
/*!*************************************************!*\
  !*** ./src/app/pages/gallery/gallery.page.scss ***!
  \*************************************************/
/***/ ((module) => {

module.exports = "ion-content ion-card {\n  --background:#2eb85c;\n}\nion-content ion-item {\n  --background:#2eb85c;\n}\nion-content p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdhbGxlcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0Usb0JBQUE7QUFBTjtBQUVJO0VBQ0Usb0JBQUE7QUFBTjtBQUdNO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFNBQUE7QUFEUiIsImZpbGUiOiJnYWxsZXJ5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xuICAgIGlvbi1jYXJke1xuICAgICAgLS1iYWNrZ3JvdW5kOiMyZWI4NWM7XG4gICAgfVxuICAgIGlvbi1pdGVte1xuICAgICAgLS1iYWNrZ3JvdW5kOiMyZWI4NWM7XG4gICAgfVxuICAgIFxuICAgICAgcHtcbiAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgICBsaW5lLWhlaWdodDogMjJweDtcbiAgICAgICAgY29sb3I6ICM4YzhjOGM7XG4gICAgICAgIG1hcmdpbjowO1xuICAgICAgfVxuICAgIH1cbiAgICAiXX0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_gallery_gallery_module_ts.js.map