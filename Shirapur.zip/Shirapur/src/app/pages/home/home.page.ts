import { Component } from '@angular/core';
import{Router,NavigationExtras} from '@angular/router'
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss']
})
export class HomePage {
  subjects:any;
  constructor(private router:Router){}
  ngOnInit(){
this.subjects=[{
  img:'assets/avt.jpg',
  name:'Home'
}];

  }

  goToSubject(){}
}
