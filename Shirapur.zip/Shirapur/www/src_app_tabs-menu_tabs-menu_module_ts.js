"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tabs-menu_tabs-menu_module_ts"],{

/***/ 5006:
/*!*********************************************************************************************************************************************************!*\
  !*** ./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/tabs-menu/tabs-menu.page.html ***!
  \*********************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-tabs>\n\n  <ion-tab-bar slot=\"bottom\">\n    <ion-tab-button tab=\"home\">\n      <ion-icon name=\"home\"></ion-icon>\n      <ion-label>मुख्यपृष्ठ</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"gallery\">\n      <ion-icon name=\"images\"></ion-icon>\n      <ion-label>वाढदिवस</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"support\">\n      <ion-icon name=\"send\"></ion-icon>\n      <ion-label>गाव</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n\n</ion-tabs>\n");

/***/ }),

/***/ 5655:
/*!***********************************************!*\
  !*** ./src/app/tabs-menu/tabs-menu.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsMenuPageModule": () => (/* binding */ TabsMenuPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 8058);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _tabs_menu_router_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs-menu.router.module */ 869);
/* harmony import */ var _tabs_menu_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs-menu.page */ 5666);







let TabsMenuPageModule = class TabsMenuPageModule {
};
TabsMenuPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _tabs_menu_router_module__WEBPACK_IMPORTED_MODULE_0__.TabsMenuPageRoutingModule
        ],
        declarations: [_tabs_menu_page__WEBPACK_IMPORTED_MODULE_1__.TabsMenuPage]
    })
], TabsMenuPageModule);



/***/ }),

/***/ 5666:
/*!*********************************************!*\
  !*** ./src/app/tabs-menu/tabs-menu.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsMenuPage": () => (/* binding */ TabsMenuPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_tabs_menu_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./tabs-menu.page.html */ 5006);
/* harmony import */ var _tabs_menu_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs-menu.page.scss */ 7753);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);




let TabsMenuPage = class TabsMenuPage {
};
TabsMenuPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-tabs-menu',
        template: _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_tabs_menu_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_tabs_menu_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], TabsMenuPage);



/***/ }),

/***/ 869:
/*!******************************************************!*\
  !*** ./src/app/tabs-menu/tabs-menu.router.module.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsMenuPageRoutingModule": () => (/* binding */ TabsMenuPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _tabs_menu_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs-menu.page */ 5666);




const routes = [
    {
        path: 'tabs',
        component: _tabs_menu_page__WEBPACK_IMPORTED_MODULE_0__.TabsMenuPage,
        children: [
            {
                path: 'home',
                children: [
                    { path: '', loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_home_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../pages/home/home.module */ 6177)).then(m => m.HomePageModule) }
                ]
            },
            {
                path: 'map',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_map_map_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../pages/map/map.module */ 1601)).then(m => m.MapModule)
                    }
                ]
            },
            {
                path: 'gallery',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_gallery_gallery_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../pages/gallery/gallery.module */ 3297)).then(m => m.GalleryPageModule)
                    }
                ]
            },
            {
                path: 'about',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_about_about_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../pages/about/about.module */ 2047)).then(m => m.AboutModule)
                    }
                ]
            },
            {
                path: 'support',
                children: [
                    {
                        path: '',
                        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_support_support_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../pages/support/support.module */ 2432)).then(m => m.SupportModule)
                    }
                ]
            },
            {
                path: '',
                redirectTo: '/app/tabs/home',
                pathMatch: 'full'
            }
        ]
    },
    /*
      {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full'
      }
    */
];
let TabsMenuPageRoutingModule = class TabsMenuPageRoutingModule {
};
TabsMenuPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], TabsMenuPageRoutingModule);



/***/ }),

/***/ 7753:
/*!***********************************************!*\
  !*** ./src/app/tabs-menu/tabs-menu.page.scss ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "/*\nion-tab-bar{\n  overflow-x:scroll;\n  justify-content: left;\n}\n*/\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYnMtbWVudS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7Ozs7O0NBQUEiLCJmaWxlIjoidGFicy1tZW51LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuLypcbmlvbi10YWItYmFye1xuICBvdmVyZmxvdy14OnNjcm9sbDtcbiAganVzdGlmeS1jb250ZW50OiBsZWZ0O1xufVxuKi8iXX0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_tabs-menu_tabs-menu_module_ts.js.map