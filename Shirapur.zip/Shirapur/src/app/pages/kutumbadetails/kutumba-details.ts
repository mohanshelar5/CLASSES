import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { AlertController, ToastController } from '@ionic/angular';
import { ConferenceData } from 'src/app/providers/conference-data';


@Component({
  selector: 'page-kutumba-details',
  templateUrl: 'kutumba-details.html',
  styleUrls: ['./kutumba-details.scss'],
})
export class KutumbaDetailsPage implements OnInit{
  submitted = false;
  supportMessage: string;
  baseURL = "https://shirapur.pythonanywhere.com/media/";
todoList=[];
          kutumbId:string;
          vasti:string;
  constructor(
    public alertCtrl: AlertController,
    public toastCtrl: ToastController,private router: Router,private data: ConferenceData,
    private route: ActivatedRoute,
  ) { }
  ngOnInit() {
    this.kutumbId=this.router.getCurrentNavigation().extras.state.kutumbId;
    this.vasti=this.router.getCurrentNavigation().extras.state.vasti;
    // this.route.queryParams.subscribe((params) => {
  
    //   this.kutumbId=this.router.getCurrentNavigation().extras.state.kutumbId;
    // this.vasti=this.router.getCurrentNavigation().extras.state.vasti;
    // console.log(this.router.getCurrentNavigation().extras.state)
    // });
    
    this.todoList=[];
    const formData = new FormData();
    formData.set('token', window.localStorage.getItem("Token"));
    formData.set('parent_id', this.kutumbId);
    formData.set('wasti_name', this.vasti)
    this.data.post("/api/home_info/",formData).subscribe(data => {
      this.todoList=JSON.parse(data.Info);
      console.log(data);
    });

  }
  // async ionViewDidEnter() {
  //   const toast = await this.toastCtrl.create({
  //     message: 'This does not actually send a support request.',
  //     duration: 3000
  //   });
  //   await toast.present();
  // }

  // async submit(form: NgForm) {
  //   this.submitted = true;

  //   if (form.valid) {
  //     this.supportMessage = '';
  //     this.submitted = false;

  //     const toast = await this.toastCtrl.create({
  //       message: 'Your support request has been sent.',
  //       duration: 3000
  //     });
  //     await toast.present();
  //   }
  // }

  // If the user enters text in the support question and then navigates
  // without submitting first, ask if they meant to leave the page
  // async ionViewCanLeave(): Promise<boolean> {
  //   // If the support message is empty we should just navigate
  //   if (!this.supportMessage || this.supportMessage.trim().length === 0) {
  //     return true;
  //   }

  //   return new Promise((resolve: any, reject: any) => {
  //     const alert = await this.alertCtrl.create({
  //       title: 'Leave this page?',
  //       message: 'Are you sure you want to leave this page? Your support message will not be submitted.',
  //       buttons: [
  //         { text: 'Stay', handler: reject },
  //         { text: 'Leave', role: 'cancel', handler: resolve }
  //       ]
  //     });

  //     await alert.present();
  //   });
  // }
}