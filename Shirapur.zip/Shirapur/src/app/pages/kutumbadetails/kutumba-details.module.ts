import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { KutumbaDetailsPage } from './kutumba-details';
import { KutumbaDetailsPageRoutingModule } from './kutumba-details-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    KutumbaDetailsPageRoutingModule
  ],
  declarations: [
    KutumbaDetailsPage,
  ]
})
export class KutumbaDetailsModule{ }
