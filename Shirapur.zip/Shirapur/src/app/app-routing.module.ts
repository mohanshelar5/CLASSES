import { NgModule } from '@angular/core';
import { PreloadAllModules,Routes, RouterModule, NoPreloading } from '@angular/router';
import { ConferenceData } from './providers/conference-data';
const routes: Routes = [
 /*
  {
    path: '',
    redirectTo: '/tutorial',
    pathMatch: 'full'
  },
  
  {
    path: '',
    loadChildren: './tabs-menu/tabs-menu.module#TabsMenuPageModule'
  },

*/
  {
    path: 'account',
    loadChildren: () => import('./pages/account/account.module').then(m => m.AccountModule)
  },
    {
    path: 'login',
    loadChildren: () => import('./login_new/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'app',
    loadChildren: () => import('./tabs-menu/tabs-menu.module').then(m => m.TabsMenuPageModule)
  },
  {
    path: 'support',
    loadChildren: () => import('./pages/support/support.module').then(m => m.SupportModule)
  }, {
    path: '',
    loadChildren: () => import('./welcome/welcome.module').then( m => m.WelcomePageModule)
  },
  {
    path: 'kutumba',
    children: [
      {
        path: '',
        loadChildren: () => import('./pages/kutumba/kutumba.module').then(m => m.KutumbaModule)
      }
    ]
  },{
    path: 'kutumba-details',
    children: [
      {
        path: '',
        loadChildren: () => import('./pages/kutumbadetails/kutumba-details.module').then(m => m.KutumbaDetailsModule)
      }
    ]
  },
  {
    path: 'village',
    children: [
      {
        path: '',
        loadChildren: () => import('./pages/village/village.module').then(m => m.VillageModule)
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ preloadingStrategy: NoPreloading })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
