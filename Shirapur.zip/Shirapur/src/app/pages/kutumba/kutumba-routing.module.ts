import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { KutumbaPage } from './kutumba';

const routes: Routes = [
  {
    path: '',
    component: KutumbaPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class KutumbaPageRoutingModule { }
