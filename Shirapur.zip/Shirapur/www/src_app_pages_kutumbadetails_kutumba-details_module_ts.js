"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_kutumbadetails_kutumba-details_module_ts"],{

/***/ 788:
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/kutumbadetails/kutumba-details.html ***!
  \*********************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      \n      <ion-back-button></ion-back-button>\n      \n  </ion-buttons>\n    <ion-title>कुटूंब</ion-title>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n  <ion-card *ngFor=\"let item of todoList\" class=\"ion-margin\">\n  <ion-card-header>\n  \n  <ion-item>\n    <ion-icon name=\"ellipse\"></ion-icon>\n    <ion-label> <img [src]=\"baseURL+item.fields.photo\"><br>{{item.fields.name}}</ion-label>\n  </ion-item>\n  </ion-card-header>\n  <!-- <ion-card-content>\n    <ion-label>Due {{item.itemName}}</ion-label>\n  </ion-card-content> -->\n  <ion-row>\n    <ion-item>\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>जन्मतारीख : {{item.fields.birth_date}}</p>\n    </ion-item>\n    <ion-item>\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>गाव : शिरापूर</p>\n    </ion-item>\n    <ion-item href=\"https://wa.me/91 {{item.fields.phone_no}} India?text=Hello\">\n      <ion-icon name=\"call\">\n      </ion-icon>\n      <p>मोबाईल नंबर : {{item.fields.phone_no}}</p>  &nbsp;&nbsp;&nbsp;\n      <ion-icon  name=\"logo-whatsapp\"></ion-icon>\n    </ion-item>\n  </ion-row>\n\n  </ion-card>\n</ion-content>");

/***/ }),

/***/ 9935:
/*!************************************************************************!*\
  !*** ./src/app/pages/kutumbadetails/kutumba-details-routing.module.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KutumbaDetailsPageRoutingModule": () => (/* binding */ KutumbaDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _kutumba_details__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./kutumba-details */ 6054);




const routes = [
    {
        path: '',
        component: _kutumba_details__WEBPACK_IMPORTED_MODULE_0__.KutumbaDetailsPage
    }
];
let KutumbaDetailsPageRoutingModule = class KutumbaDetailsPageRoutingModule {
};
KutumbaDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], KutumbaDetailsPageRoutingModule);



/***/ }),

/***/ 1557:
/*!****************************************************************!*\
  !*** ./src/app/pages/kutumbadetails/kutumba-details.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KutumbaDetailsModule": () => (/* binding */ KutumbaDetailsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8058);
/* harmony import */ var _kutumba_details__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./kutumba-details */ 6054);
/* harmony import */ var _kutumba_details_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./kutumba-details-routing.module */ 9935);







let KutumbaDetailsModule = class KutumbaDetailsModule {
};
KutumbaDetailsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _kutumba_details_routing_module__WEBPACK_IMPORTED_MODULE_1__.KutumbaDetailsPageRoutingModule
        ],
        declarations: [
            _kutumba_details__WEBPACK_IMPORTED_MODULE_0__.KutumbaDetailsPage,
        ]
    })
], KutumbaDetailsModule);



/***/ }),

/***/ 6054:
/*!*********************************************************!*\
  !*** ./src/app/pages/kutumbadetails/kutumba-details.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KutumbaDetailsPage": () => (/* binding */ KutumbaDetailsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_kutumba_details_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./kutumba-details.html */ 788);
/* harmony import */ var _kutumba_details_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./kutumba-details.scss */ 2370);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 8058);
/* harmony import */ var src_app_providers_conference_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/conference-data */ 4700);







let KutumbaDetailsPage = class KutumbaDetailsPage {
    constructor(alertCtrl, toastCtrl, router, data, route) {
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.router = router;
        this.data = data;
        this.route = route;
        this.submitted = false;
        this.baseURL = "https://shirapur.pythonanywhere.com/media/";
        this.todoList = [];
    }
    ngOnInit() {
        this.kutumbId = this.router.getCurrentNavigation().extras.state.kutumbId;
        this.vasti = this.router.getCurrentNavigation().extras.state.vasti;
        // this.route.queryParams.subscribe((params) => {
        //   this.kutumbId=this.router.getCurrentNavigation().extras.state.kutumbId;
        // this.vasti=this.router.getCurrentNavigation().extras.state.vasti;
        // console.log(this.router.getCurrentNavigation().extras.state)
        // });
        this.todoList = [];
        const formData = new FormData();
        formData.set('token', window.localStorage.getItem("Token"));
        formData.set('parent_id', this.kutumbId);
        formData.set('wasti_name', this.vasti);
        this.data.post("/api/home_info/", formData).subscribe(data => {
            this.todoList = JSON.parse(data.Info);
            console.log(data);
        });
    }
};
KutumbaDetailsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ToastController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: src_app_providers_conference_data__WEBPACK_IMPORTED_MODULE_2__.ConferenceData },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute }
];
KutumbaDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'page-kutumba-details',
        template: _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_kutumba_details_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_kutumba_details_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], KutumbaDetailsPage);



/***/ }),

/***/ 2370:
/*!***********************************************************!*\
  !*** ./src/app/pages/kutumbadetails/kutumba-details.scss ***!
  \***********************************************************/
/***/ ((module) => {

module.exports = "ion-back-button {\n  display: block;\n}\n\nion-content ion-card {\n  --background:#F0F4FD;\n}\n\nion-content ion-item {\n  --background:#F0F4FD;\n}\n\nion-content p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImt1dHVtYmEtZGV0YWlscy5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtBQUNGOztBQUVBO0VBQ0Usb0JBQUE7QUFDRjs7QUFDQTtFQUNFLG9CQUFBO0FBQ0Y7O0FBRUU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsU0FBQTtBQUFKIiwiZmlsZSI6Imt1dHVtYmEtZGV0YWlscy5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWJhY2stYnV0dG9uIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5pb24tY29udGVudHtcbmlvbi1jYXJke1xuICAtLWJhY2tncm91bmQ6I0YwRjRGRDtcbn1cbmlvbi1pdGVte1xuICAtLWJhY2tncm91bmQ6I0YwRjRGRDtcbn1cblxuICBwe1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBsaW5lLWhlaWdodDogMjJweDtcbiAgICBjb2xvcjogIzhjOGM4YztcbiAgICBtYXJnaW46MDtcbiAgfVxufVxuIl19 */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_kutumbadetails_kutumba-details_module_ts.js.map