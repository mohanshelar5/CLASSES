import { Component } from '@angular/core';

@Component({
  selector: 'app-tabs-menu',
  templateUrl: 'tabs-menu.page.html',
  styleUrls: ['tabs-menu.page.scss']
})
export class TabsMenuPage {}
