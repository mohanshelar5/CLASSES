
import { Injectable } from '@angular/core';
import { Observable,of } from 'rxjs';
import { HTTP, HTTPResponse } from '@awesome-cordova-plugins/http/ngx';
import { Platform } from '@ionic/angular';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// //const baseUrl="https://shirapur.pythonanywhere.com/app/";
// const baseUrl="http://dummy.restapiexample.com/api/v1/create";

@Injectable({
  providedIn: 'root'
})
export class ConferenceData {
  private headers = {
  
  };

  private httpOptions = {
    headers: this.headers
  };

  private baseURL = "https://shirapur.pythonanywhere.com";

  isCordova = this.platform.is('cordova');

  constructor(private nhttp: HTTP, private aghttp: HttpClient, private platform: Platform) {
   
  }

  get(url: string, parameters: any = null): Observable<any> {
    const endpoint = `${this.baseURL}${url}`;
    if (this.isCordova) {
      return this.nativeHttpWrapper('get', endpoint, parameters);
    } else {
      Object.assign(this.httpOptions, { params: parameters });
      return this.aghttp.get(endpoint, this.httpOptions);
    }
  }

  post(url: string, formData: FormData): Observable<any> {
    debugger;
   
    
    
    const endpoint = `${this.baseURL}${url}`;
    if (this.isCordova) {
      return this.nativeHttpWrapper('post', endpoint, formData);
    } else {
      return this.aghttp.post(endpoint, formData, this.httpOptions);
    }
  }

  nativeHttpWrapper(methods: string, url: string, formData: FormData): Observable<any> {
    return new Observable((observer) => {
      let options = {
        method: methods,
        responseType: 'json ',
      };
      if (methods === 'post') {
        options['serializer'] = 'multipart';
        options['data'] = formData;
      }
      this.nhttp.sendRequest(url, options).then(data => {
        console.log(data.status);
        console.log(data.data);
        console.log(data.headers);
        observer.next(data.data);
        observer.complete();
      },error => {
        console.log(error.status);
        console.log(error.error);
        console.log(error.headers);
        observer.error(error);
        observer.complete();
      })
        .catch(error => {
          console.log(error.status);
          console.log(error.error);
          console.log(error.headers);
          observer.error(error);
          observer.complete();
        });
    })
  }


}
