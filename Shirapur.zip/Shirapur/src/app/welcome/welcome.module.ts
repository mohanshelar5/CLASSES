import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LoginPage } from '../login_new/login.page';
import { RegisterPage } from '../register/register.page';
import { IonicModule } from '@ionic/angular';

import { WelcomePageRoutingModule } from './welcome-routing.module';

import { WelcomePage } from './welcome.page';
import { ConferenceData } from '../providers/conference-data';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    WelcomePageRoutingModule
  ],providers: [ConferenceData],
  declarations: [WelcomePage,LoginPage,RegisterPage],
entryComponents: [LoginPage,RegisterPage ]
})
export class WelcomePageModule {}
