import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ConferenceData } from 'src/app/providers/conference-data';
import { PhotoService } from '../../services/photo.service';

@Component({
  selector: 'app-gallery',
  templateUrl: 'gallery.page.html',
  styleUrls: ['gallery.page.scss']
})
export class GalleryPage {
  currentImage: any;
  todoList=[];
  baseURL = "https://shirapur.pythonanywhere.com/media/";
              constructor(public photoService: PhotoService,private data: ConferenceData,private router: Router) {  }

              ngOnInit() {
    this.todoList=[];
    const formData = new FormData();
    formData.set('token', window.localStorage.getItem("Token"));
   
    this.data.post("/api/birthdays/",formData).subscribe(data => {
      this.todoList=JSON.parse(data.birth_day_today);
      console.log(data);
    });

}
openKutumbaDetails(kutumbId,vasti){
  //this.router.navigateByUrl('/app/tabs/kutumba-details');
  debugger;
  this.router.navigate(['/app/tabs/kutumba-details'], { state: { kutumbId: kutumbId,vasti:vasti } });
}
}