"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_kutumba_kutumba_module_ts"],{

/***/ 3278:
/*!******************************************************************************************************************************************************!*\
  !*** ./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/kutumba/kutumba.html ***!
  \******************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>कुटूंब प्रमुख</ion-title>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n  <ion-card *ngFor=\"let item of todoList\" class=\"ion-margin\" (click)=\"openKutumbaDetails(item.fields.parent_id)\">\n  <ion-card-header>\n  \n  <ion-item>\n    <ion-icon name=\"ellipse\"></ion-icon>\n    <ion-label>{{item.fields.name}}</ion-label>\n  </ion-item>\n  </ion-card-header>\n  <!-- <ion-card-content>\n    <ion-label>Due {{item.itemName}}</ion-label>\n  </ion-card-content> -->\n  <ion-row>\n    <ion-item>\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>कुटूंब सदश्य संख्या : 3</p>\n    </ion-item>\n    <ion-item>\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>मतदार : 2</p>\n    </ion-item>\n    <ion-item>\n      <ion-icon name=\"call\">\n      </ion-icon>\n      <p>मोबाईल नंबर : {{item.fields.phone_no}}</p>  &nbsp;&nbsp;&nbsp;<ion-icon name=\"logo-whatsapp\"></ion-icon>\n    </ion-item>\n    <ion-item>\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>जन्मतारीख : {{item.fields.birth_date}}</p>\n    </ion-item>\n  </ion-row>\n  \n  </ion-card>\n</ion-content>");

/***/ }),

/***/ 2845:
/*!*********************************************************!*\
  !*** ./src/app/pages/kutumba/kutumba-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KutumbaPageRoutingModule": () => (/* binding */ KutumbaPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _kutumba__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./kutumba */ 6324);




const routes = [
    {
        path: '',
        component: _kutumba__WEBPACK_IMPORTED_MODULE_0__.KutumbaPage
    }
];
let KutumbaPageRoutingModule = class KutumbaPageRoutingModule {
};
KutumbaPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], KutumbaPageRoutingModule);



/***/ }),

/***/ 1111:
/*!*************************************************!*\
  !*** ./src/app/pages/kutumba/kutumba.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KutumbaModule": () => (/* binding */ KutumbaModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8058);
/* harmony import */ var _kutumba__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./kutumba */ 6324);
/* harmony import */ var _kutumba_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./kutumba-routing.module */ 2845);







let KutumbaModule = class KutumbaModule {
};
KutumbaModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _kutumba_routing_module__WEBPACK_IMPORTED_MODULE_1__.KutumbaPageRoutingModule
        ],
        declarations: [
            _kutumba__WEBPACK_IMPORTED_MODULE_0__.KutumbaPage,
        ]
    })
], KutumbaModule);



/***/ }),

/***/ 6324:
/*!******************************************!*\
  !*** ./src/app/pages/kutumba/kutumba.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KutumbaPage": () => (/* binding */ KutumbaPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_kutumba_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./kutumba.html */ 3278);
/* harmony import */ var _kutumba_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./kutumba.scss */ 7273);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 8058);
/* harmony import */ var src_app_providers_conference_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/providers/conference-data */ 4700);







let KutumbaPage = class KutumbaPage {
    constructor(alertCtrl, toastCtrl, router, data, navCtrl) {
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.router = router;
        this.data = data;
        this.navCtrl = navCtrl;
        this.submitted = false;
        this.todoList = [];
    }
    ngOnInit() {
        this.vasti = this.router.getCurrentNavigation().extras.state.vasti;
        this.todoList = [];
        const formData = new FormData();
        formData.set('token', window.localStorage.getItem("Token"));
        formData.set('wasti_name', this.vasti);
        debugger;
        this.data.post("/api/main_wasti_member/", formData).subscribe(data => {
            this.todoList = JSON.parse(data.Info);
            console.log(data);
        });
    }
    openKutumbaDetails(kutumbId) {
        //this.router.navigateByUrl('/app/tabs/kutumba-details');
        this.navCtrl.navigateForward(['/kutumba-details'], { state: { kutumbId: kutumbId, vasti: this.vasti } });
        //  this.router.navigate(['/app/tabs/kutumba-details'], { state: { kutumbId: kutumbId,vasti:this.vasti } });
    }
};
KutumbaPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ToastController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: src_app_providers_conference_data__WEBPACK_IMPORTED_MODULE_2__.ConferenceData },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController }
];
KutumbaPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'page-kutumba',
        template: _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_kutumba_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_kutumba_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], KutumbaPage);



/***/ }),

/***/ 7273:
/*!********************************************!*\
  !*** ./src/app/pages/kutumba/kutumba.scss ***!
  \********************************************/
/***/ ((module) => {

module.exports = "ion-content ion-card {\n  --background:#F0F4FD;\n}\nion-content ion-item {\n  --background:#F0F4FD;\n}\nion-content p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImt1dHVtYmEuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLG9CQUFBO0FBQUY7QUFFQTtFQUNFLG9CQUFBO0FBQUY7QUFHRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBREoiLCJmaWxlIjoia3V0dW1iYS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XG5pb24tY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiNGMEY0RkQ7XG59XG5pb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiNGMEY0RkQ7XG59XG5cbiAgcHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XG4gICAgY29sb3I6ICM4YzhjOGM7XG4gICAgbWFyZ2luOjA7XG4gIH1cbn1cbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_kutumba_kutumba_module_ts.js.map