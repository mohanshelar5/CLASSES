import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController, NavController, ToastController } from '@ionic/angular';
import { ConferenceData } from 'src/app/providers/conference-data';


@Component({
  selector: 'page-kutumba',
  templateUrl: 'kutumba.html',
  styleUrls: ['./kutumba.scss'],
})
export class KutumbaPage implements OnInit{
  submitted = false;
  vasti:string;
  supportMessage: string;
todoList=[];
  constructor(
    public alertCtrl: AlertController,
    public toastCtrl: ToastController,private router: Router,private data: ConferenceData,
    public navCtrl: NavController
  ) { }
  ngOnInit() {
    this.vasti=this.router.getCurrentNavigation().extras.state.vasti;
this.todoList=[];
    const formData = new FormData();
    formData.set('token', window.localStorage.getItem("Token"))
    formData.set('wasti_name', this.vasti)
    debugger;
    this.data.post("/api/main_wasti_member/",formData).subscribe(data => {
      this.todoList=JSON.parse(data.Info);
      console.log(data);
    });

  }
  openKutumbaDetails(kutumbId){
    //this.router.navigateByUrl('/app/tabs/kutumba-details');
   this.navCtrl.navigateForward(['/kutumba-details'],{ state: { kutumbId: kutumbId,vasti:this.vasti } });
  //  this.router.navigate(['/app/tabs/kutumba-details'], { state: { kutumbId: kutumbId,vasti:this.vasti } });
  }



  // async ionViewDidEnter() {
  //   const toast = await this.toastCtrl.create({
  //     message: 'This does not actually send a support request.',
  //     duration: 3000
  //   });
  //   await toast.present();
  // }

  // async submit(form: NgForm) {
  //   this.submitted = true;

  //   if (form.valid) {
  //     this.supportMessage = '';
  //     this.submitted = false;

  //     const toast = await this.toastCtrl.create({
  //       message: 'Your support request has been sent.',
  //       duration: 3000
  //     });
  //     await toast.present();
  //   }
  // }

  // If the user enters text in the support question and then navigates
  // without submitting first, ask if they meant to leave the page
  // async ionViewCanLeave(): Promise<boolean> {
  //   // If the support message is empty we should just navigate
  //   if (!this.supportMessage || this.supportMessage.trim().length === 0) {
  //     return true;
  //   }

  //   return new Promise((resolve: any, reject: any) => {
  //     const alert = await this.alertCtrl.create({
  //       title: 'Leave this page?',
  //       message: 'Are you sure you want to leave this page? Your support message will not be submitted.',
  //       buttons: [
  //         { text: 'Stay', handler: reject },
  //         { text: 'Leave', role: 'cancel', handler: resolve }
  //       ]
  //     });

  //     await alert.present();
  //   });
  // }
}