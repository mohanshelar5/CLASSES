import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { VillagePage } from './village';
import { VillagePageRoutingModule } from './village-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    VillagePageRoutingModule
  ],
  declarations: [
    VillagePage,
  ]
})
export class VillageModule { }
