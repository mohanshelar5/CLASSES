"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_home_module_ts"],{

/***/ 9584:
/*!*****************************************************************************************************************************************************!*\
  !*** ./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/home/home.page.html ***!
  \*****************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n<div class=\"main_content_div\">\n\n<ion-buttons slot=\"start\" class=\"menu_btn\">\n<ion-menu-button color=\"light\"></ion-menu-button>\n</ion-buttons>\n<div class=\"user_div\">\n<div class=\"first_div\">\n<ion-label class=\"welcome\">Welcome</ion-label>\n<ion-label class=\"username\">Mohan</ion-label>\n</div>\n<div class=\"user_back\" [style.backgroundImage]=\"'url(assets/avt.jpg)'\"></div>\n</div>\n<div class=\"content_div animated bounceInUp\">\n<!-- <ion-label class=\"hello_lbl\">Hello, Pleade Choose Your Subject</ion-label> -->\n<ion-grid fixed>\n  <ion-row>\n    <ion-col size=\"6\" (click)=\"goToSubject()\">\n      <div class=\"col_div\">\n        <ion-label><b>लोकसंख्या</b></ion-label>\n        <ion-label>3000</ion-label>\n      </div>\n    </ion-col>\n    <ion-col size=\"6\" (click)=\"goToSubject()\">\n      <div class=\"col_div1\">\n        <ion-label><B>मतदार</B></ion-label>\n        <ion-label>2000</ion-label>\n      </div>\n    </ion-col>\n    <ion-col size=\"6\" (click)=\"goToSubject()\">\n      <div class=\"col_div2\">\n        <ion-label><b>एकुन गाव संख्या</b></ion-label>\n        <ion-label>1</ion-label>\n      </div>\n    </ion-col>\n    <ion-col size=\"6\" (click)=\"goToSubject()\">\n      <div class=\"col_div3\">\n        <ion-label><b>एकुन वस्ती संख्या</b></ion-label>\n        <ion-label>8</ion-label>\n      </div>\n    </ion-col>\n    <ion-col size=\"6\" (click)=\"goToSubject()\">\n      <div class=\"col_div4\">\n        <ion-label><b>एकुन कुटूंब संख्या</b></ion-label>\n        <ion-label>2000</ion-label>\n      </div>\n    </ion-col>\n    <ion-col size=\"6\" (click)=\"goToSubject()\">\n      <div class=\"col_div5\">\n        <ion-label><B>मतदार</B></ion-label>\n        <ion-label>2000</ion-label>\n      </div>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n\n</div>\n</div>\n</ion-content>\n");

/***/ }),

/***/ 6177:
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 8058);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 4095);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild([{ path: '', component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage }])
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 4095:
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./home.page.html */ 9584);
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss */ 932);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 3252);





let HomePage = class HomePage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
        this.subjects = [{
                img: 'assets/avt.jpg',
                name: 'Home'
            }];
    }
    goToSubject() { }
};
HomePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-home',
        template: _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_home_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 932:
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.scss ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  --background:linear-gradient(to right,#ee4659,#ee4659);\n}\n\n.main_content_div {\n  width: 100%;\n}\n\n.main_content_div .menu_btn {\n  position: relative;\n  top: 4px;\n  left: 3px;\n}\n\n.main_content_div ion-label {\n  display: block;\n  color: #d8107c;\n  text-align: center;\n}\n\n.main_content_div .user_div {\n  padding: 20px;\n  width: 100%;\n  height: 87px;\n  background: linear-gradient(to right, #ee4659, #ee4659);\n  display: flex;\n  padding-top: 18px;\n  justify-content: space-between;\n}\n\n.main_content_div .user_div .first_div {\n  padding-top: 35px;\n}\n\n.main_content_div .user_div .first_div .welcome {\n  font-size: 18px;\n  color: white;\n  font-weight: 500;\n}\n\n.main_content_div .user_div .first_div .username {\n  font-size: 24px;\n  color: white;\n  font-weight: 600;\n}\n\n.main_content_div .user_div .user_back {\n  height: 100px;\n  width: 80px;\n  border: 3px solid white;\n  background-position: top;\n  background-size: cover;\n  background-repeat: no-repeat;\n  border-radius: 7px;\n}\n\n.main_content_div .content_div {\n  background: white;\n  width: 100%;\n  margin-top: 57px;\n  padding-top: 30px;\n}\n\n.main_content_div .content_div .hello_lbl {\n  font-weight: 600;\n  font-size: 18px;\n  margin-bottom: 10px;\n  padding-left: 5px;\n  margin-top: 10px;\n}\n\n.main_content_div .content_div ion-grid {\n  padding: 0px;\n}\n\n.main_content_div .content_div .col_div {\n  background: #0dcaf0;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 5px;\n}\n\n.main_content_div .content_div .col_div img {\n  width: 70px;\n}\n\n.main_content_div .content_div .col_div ion-label {\n  color: white;\n  margin-top: 5px;\n}\n\n.main_content_div .content_div .col_div1 {\n  background: #2eb85c;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 5px;\n}\n\n.main_content_div .content_div .col_div1 img {\n  width: 70px;\n}\n\n.main_content_div .content_div .col_div1 ion-label {\n  color: WHITE;\n  margin-top: 5px;\n}\n\n.main_content_div .content_div .col_div2 {\n  background: #f9b115;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 5px;\n}\n\n.main_content_div .content_div .col_div2 img {\n  width: 70px;\n}\n\n.main_content_div .content_div .col_div2 ion-label {\n  color: WHITE;\n  margin-top: 5px;\n}\n\n.main_content_div .content_div .col_div3 {\n  background: linear-gradient(90deg, #d8107c 0%, #d8107c 100%);\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 5px;\n}\n\n.main_content_div .content_div .col_div3 img {\n  width: 70px;\n}\n\n.main_content_div .content_div .col_div3 ion-label {\n  color: WHITE;\n  margin-top: 5px;\n}\n\n.main_content_div .content_div .col_div4 {\n  background: #dc3545;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 5px;\n}\n\n.main_content_div .content_div .col_div4 img {\n  width: 70px;\n}\n\n.main_content_div .content_div .col_div4 ion-label {\n  color: WHITE;\n  margin-top: 5px;\n}\n\n.main_content_div .content_div .col_div5 {\n  background: #6f42c1;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  text-align: center;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 5px;\n}\n\n.main_content_div .content_div .col_div5 img {\n  width: 70px;\n}\n\n.main_content_div .content_div .col_div5 ion-label {\n  color: WHITE;\n  margin-top: 5px;\n}\n\n.animated {\n  animation-duration: 10s;\n  animation-fill-mode: both;\n}\n\n.bounceInUp {\n  animation-name: bounceInUp;\n}\n\n@keyframes bounceInUp {\n  0% {\n    opacity: 0;\n    -webkit-transform: translateY(2000px);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translateY(-30px);\n  }\n  80% {\n    -webkit-transform: translateY(10px);\n  }\n  100% {\n    -webkit-transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usc0RBQUE7QUFDRjs7QUFFQTtFQUNFLFdBQUE7QUFDRjs7QUFDRTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7QUFDSjs7QUFDQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFDRTtFQUNFLGFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHVEQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsOEJBQUE7QUFDSjs7QUFDRTtFQUNFLGlCQUFBO0FBQ0o7O0FBQ0U7RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBQ0U7RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQ0o7O0FBRUU7RUFDRSxhQUFBO0VBQ0EsV0FBQTtFQUNBLHVCQUFBO0VBQ0Esd0JBQUE7RUFDQSxzQkFBQTtFQUNBLDRCQUFBO0VBQ0Esa0JBQUE7QUFBSjs7QUFHRTtFQUNFLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFESjs7QUFHSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUROOztBQUdJO0VBQ0UsWUFBQTtBQUROOztBQUdHO0VBQ0MsbUJBQUE7RUFDQyxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsMENBQUE7RUFDQSxrQkFBQTtBQURMOztBQUdLO0VBQ0UsV0FBQTtBQURQOztBQUlLO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUFGUDs7QUFLRztFQUNDLG1CQUFBO0VBQ0MsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7QUFITDs7QUFLSztFQUNFLFdBQUE7QUFIUDs7QUFNSztFQUNFLFlBQUE7RUFDQSxlQUFBO0FBSlA7O0FBT0c7RUFDQyxtQkFBQTtFQUNDLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSwwQ0FBQTtFQUNBLGtCQUFBO0FBTEw7O0FBT0s7RUFDRSxXQUFBO0FBTFA7O0FBUUs7RUFDRSxZQUFBO0VBQ0EsZUFBQTtBQU5QOztBQVNHO0VBQ0MsNERBQUE7RUFDQyxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsMENBQUE7RUFDQSxrQkFBQTtBQVBMOztBQVNLO0VBQ0UsV0FBQTtBQVBQOztBQVVLO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUFSUDs7QUFXRztFQUNDLG1CQUFBO0VBQ0MsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7QUFUTDs7QUFXSztFQUNFLFdBQUE7QUFUUDs7QUFZSztFQUNFLFlBQUE7RUFDQSxlQUFBO0FBVlA7O0FBYUc7RUFDQyxtQkFBQTtFQUNDLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSwwQ0FBQTtFQUNBLGtCQUFBO0FBWEw7O0FBYUs7RUFDRSxXQUFBO0FBWFA7O0FBY0s7RUFDRSxZQUFBO0VBQ0EsZUFBQTtBQVpQOztBQWtCQTtFQUVFLHVCQUFBO0VBRUEseUJBQUE7QUFmRjs7QUFpQ0E7RUFFRSwwQkFBQTtBQWRGOztBQWlCQTtFQUNFO0lBQ0UsVUFBQTtJQUNBLHFDQUFBO0VBZEY7RUFnQkE7SUFDRSxVQUFBO0lBQ0Esb0NBQUE7RUFkRjtFQWdCQTtJQUNFLG1DQUFBO0VBZEY7RUFnQkE7SUFDRSxnQ0FBQTtFQWRGO0FBQ0YiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcbiAgLS1iYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCh0byByaWdodCwjZWU0NjU5LCNlZTQ2NTkpO1xuXG59XG4ubWFpbl9jb250ZW50X2RpdntcbiAgd2lkdGg6IDEwMCU7XG5cbiAgLm1lbnVfYnRue1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB0b3A6IDRweDtcbiAgICBsZWZ0OjNweFxuICB9XG5pb24tbGFiZWx7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBjb2xvcjogI2Q4MTA3YztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuICAudXNlcl9kaXZ7XG4gICAgcGFkZGluZzogMjBweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDg3cHg7XG4gICAgYmFja2dyb3VuZDpsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsI2VlNDY1OSwjZWU0NjU5KTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIHBhZGRpbmctdG9wOiAxOHB4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiBcbiAgLmZpcnN0X2RpdntcbiAgICBwYWRkaW5nLXRvcDogMzVweDtcbiAgXG4gIC53ZWxjb21le1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgfVxuICAudXNlcm5hbWV7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICB9XG4gIH1cbiAgLnVzZXJfYmFja3tcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIHdpZHRoOiA4MHB4O1xuICAgIGJvcmRlcjogM3B4IHNvbGlkIHdoaXRlO1xuICAgIGJhY2tncm91bmQtcG9zaXRpb246IHRvcDtcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgYm9yZGVyLXJhZGl1czogN3B4O1xuICB9XG59XG4gIC5jb250ZW50X2RpdntcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBtYXJnaW4tdG9wOiA1N3B4O1xuICAgIHBhZGRpbmctdG9wOiAzMHB4O1xuXG4gICAgLmhlbGxvX2xibHtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgcGFkZGluZy1sZWZ0OiA1cHg7XG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgIH1cbiAgICBpb24tZ3JpZHtcbiAgICAgIHBhZGRpbmc6IDBweDtcbiAgICB9XG4gICAuY29sX2RpdntcbiAgICBiYWNrZ3JvdW5kOiMwZGNhZjA7XG4gICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgIGhlaWdodDogMTUwcHg7XG4gICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwwLDAsMC4yKTtcbiAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuXG4gICAgIGltZ3tcbiAgICAgICB3aWR0aDogNzBweDtcblxuICAgICB9XG4gICAgIGlvbi1sYWJlbHtcbiAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgbWFyZ2luLXRvcDogNXB4O1xuICAgICB9XG4gICB9XG4gICAuY29sX2RpdjF7XG4gICAgYmFja2dyb3VuZDojMmViODVjO1xuICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMik7XG4gICAgIGJvcmRlci1yYWRpdXM6IDVweDtcblxuICAgICBpbWd7XG4gICAgICAgd2lkdGg6IDcwcHg7XG5cbiAgICAgfVxuICAgICBpb24tbGFiZWx7XG4gICAgICAgY29sb3I6IFdISVRFO1xuICAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICAgfVxuICAgfVxuICAgLmNvbF9kaXYye1xuICAgIGJhY2tncm91bmQ6I2Y5YjExNTtcbiAgICAgZGlzcGxheTogZmxleDtcbiAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgaGVpZ2h0OiAxNTBweDtcbiAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjIpO1xuICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG5cbiAgICAgaW1ne1xuICAgICAgIHdpZHRoOiA3MHB4O1xuXG4gICAgIH1cbiAgICAgaW9uLWxhYmVse1xuICAgICAgIGNvbG9yOiBXSElURTtcbiAgICAgICBtYXJnaW4tdG9wOiA1cHg7XG4gICAgIH1cbiAgIH1cbiAgIC5jb2xfZGl2M3tcbiAgICBiYWNrZ3JvdW5kOmxpbmVhci1ncmFkaWVudCg5MGRlZywjZDgxMDdjIDAlLCNkODEwN2MgMTAwJSk7XG4gICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgIGhlaWdodDogMTUwcHg7XG4gICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwwLDAsMC4yKTtcbiAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuXG4gICAgIGltZ3tcbiAgICAgICB3aWR0aDogNzBweDtcblxuICAgICB9XG4gICAgIGlvbi1sYWJlbHtcbiAgICAgICBjb2xvcjogV0hJVEU7XG4gICAgICAgbWFyZ2luLXRvcDogNXB4O1xuICAgICB9XG4gICB9XG4gICAuY29sX2RpdjR7XG4gICAgYmFja2dyb3VuZDojZGMzNTQ1O1xuICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMik7XG4gICAgIGJvcmRlci1yYWRpdXM6IDVweDtcblxuICAgICBpbWd7XG4gICAgICAgd2lkdGg6IDcwcHg7XG5cbiAgICAgfVxuICAgICBpb24tbGFiZWx7XG4gICAgICAgY29sb3I6IFdISVRFO1xuICAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICAgfVxuICAgfVxuICAgLmNvbF9kaXY1e1xuICAgIGJhY2tncm91bmQ6IzZmNDJjMTtcbiAgICAgZGlzcGxheTogZmxleDtcbiAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgaGVpZ2h0OiAxNTBweDtcbiAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjIpO1xuICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG5cbiAgICAgaW1ne1xuICAgICAgIHdpZHRoOiA3MHB4O1xuXG4gICAgIH1cbiAgICAgaW9uLWxhYmVse1xuICAgICAgIGNvbG9yOiBXSElURTtcbiAgICAgICBtYXJnaW4tdG9wOiA1cHg7XG4gICAgIH1cbiAgIH1cbiAgIFxuICB9XG59XG4uYW5pbWF0ZWR7XG4gIC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAxMHM7XG4gIGFuaW1hdGlvbi1kdXJhdGlvbjogMTBzO1xuICAtd2Via2l0LWFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XG4gIGFuaW1hdGlvbi1maWxsLW1vZGU6IGJvdGg7XG59XG5ALXdlYmtpdC1rZXlmcmFtZXMgYm91bmNlSW5VcHtcbiAgMCV7XG4gICAgb3BhY2l0eTogMDtcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgyMDAwcHgpO1xuICB9XG4gIDYwJXtcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtMzBweCk7XG4gIH1cbiAgODAle1xuICAgIG9wYWNpdHk6IDE7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTBweCk7XG4gIH1cbiAgMTAwJXtcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTtcbiAgfVxufVxuLmJvdW5jZUluVXB7XG4gIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IGJvdW5jZUluVXA7XG4gIGFuaW1hdGlvbi1uYW1lOiBib3VuY2VJblVwO1xufVxuXG5Aa2V5ZnJhbWVzIGJvdW5jZUluVXB7XG4gIDAle1xuICAgIG9wYWNpdHk6IDA7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMjAwMHB4KTtcbiAgfVxuICA2MCV7XG4gICAgb3BhY2l0eTogMTtcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtMzBweCk7XG4gIH1cbiAgODAle1xuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwcHgpO1xuICB9XG4gIDEwMCV7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7XG4gIH1cbn0iXX0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_home_module_ts.js.map