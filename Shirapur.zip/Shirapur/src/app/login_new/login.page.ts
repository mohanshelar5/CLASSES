import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { ConferenceData } from '../providers/conference-data';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  constructor(
    public modalCtrl: ModalController,private data: ConferenceData
  ) { 
  }
userName:string;
password:string;
  ngOnInit() {
  }
  login(){
  const formData = new FormData();
    formData.set('username', this.userName)
    formData.set('password', this.password)
  this.data.post("/app/login/",formData).subscribe(data => {
    console.log(data);
    if(data.error==='False'){
      window.localStorage.setItem("Token",data.token);
      this.modalCtrl.dismiss("success");
    }else{
      alert(data.message);
    }
  });
  
}
  async dismiss() {
    await this.modalCtrl.dismiss("close");
  }
}
