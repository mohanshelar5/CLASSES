import { Component, ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NavigationExtras, Router } from '@angular/router';
import { AlertController, NavController, ToastController } from '@ionic/angular';


@Component({
  selector: 'page-village',
  templateUrl: 'village.html',
  styleUrls: ['./village.scss'],
})
export class VillagePage {
  submitted = false;
  supportMessage: string;
todoList=[{
itemName:"शिनारे वस्ती"
},{
  itemName:"ऊचाळे वस्ती (पूर्व )"
  },{
    itemName:"ऊचाळे वस्ती (पश्चिम)"
    },{
      itemName:"भिल्ल वस्ती"
      },{
        itemName:"धनगर वस्ती"
        },{
          itemName:"मधुकर नगर"
          },{
            itemName:"भोसले वस्ती"
            },{
              itemName:"कुरण वस्ती"
              },{
                itemName:"नरसाळवाडी"
                },{
                  itemName:" खामकर वाडी"
                  },{
                    itemName:"शेळकेवस्ती"
                    },{
                      itemName:"कोल्हेवस्ती"
                      },{
                        itemName:"खाडेवस्ती"
                        },{
                          itemName:"गावठाण"
                          },{
                            itemName:"भोरवस्ती"
                            },{
                              itemName:"कानिफनाथ वस्ती"
                              },{
                                itemName:"चौधरीमळा"
                                },{
                                  itemName:"चाटे वस्ती "
                                  },{
                                    itemName:"इतर "
                                    }];
  constructor(
    public alertCtrl: AlertController,
    public toastCtrl: ToastController,private router: Router,public nav: NavController
  ) { }
  openKutumba(vastiName){
    //this.router.navigateByUrl('/app/tabs/kutumba');
    let navigationExtras: NavigationExtras = {
      queryParams: {
        special: JSON.stringify({ vasti: vastiName })
      }
    };
    this.nav.navigateForward('/kutumba',{ state: { vasti: vastiName } });
    // this.router.navigate(['/app/tabs/kutumba',navigationExtras]);
   // this.router.navigate(['/app/tabs/kutumba'], { state: { vasti: vastiName } });
  }
  // async ionViewDidEnter() {
  //   const toast = await this.toastCtrl.create({
  //     message: 'This does not actually send a support request.',
  //     duration: 3000
  //   });
  //   await toast.present();
  // }

  // async submit(form: NgForm) {
  //   this.submitted = true;

  //   if (form.valid) {
  //     this.supportMessage = '';
  //     this.submitted = false;

  //     const toast = await this.toastCtrl.create({
  //       message: 'Your support request has been sent.',
  //       duration: 3000
  //     });
  //     await toast.present();
  //   }
  // }

  // If the user enters text in the support question and then navigates
  // without submitting first, ask if they meant to leave the page
  // async ionViewCanLeave(): Promise<boolean> {
  //   // If the support message is empty we should just navigate
  //   if (!this.supportMessage || this.supportMessage.trim().length === 0) {
  //     return true;
  //   }

  //   return new Promise((resolve: any, reject: any) => {
  //     const alert = await this.alertCtrl.create({
  //       title: 'Leave this page?',
  //       message: 'Are you sure you want to leave this page? Your support message will not be submitted.',
  //       buttons: [
  //         { text: 'Stay', handler: reject },
  //         { text: 'Leave', role: 'cancel', handler: resolve }
  //       ]
  //     });

  //     await alert.present();
  //   });
  // }
}