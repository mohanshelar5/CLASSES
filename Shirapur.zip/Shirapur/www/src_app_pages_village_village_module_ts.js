"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_village_village_module_ts"],{

/***/ 9587:
/*!******************************************************************************************************************************************************!*\
  !*** ./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/village/village.html ***!
  \******************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>वस्ती</ion-title>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n  <ion-card *ngFor=\"let item of todoList\" class=\"ion-margin\" (click)=\"openKutumba(item.itemName)\">\n  <ion-card-header>\n  \n  <ion-item>\n    <ion-icon name=\"ellipse\"></ion-icon>\n    <ion-label>{{item.itemName}}</ion-label>\n  </ion-item>\n  </ion-card-header>\n  <!-- <ion-card-content>\n    <ion-label>Due {{item.itemName}}</ion-label>\n  </ion-card-content> -->\n  <ion-row>\n    <ion-item>\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>लोकसंख्या : 3000</p>\n    </ion-item>\n    <ion-item>\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>मतदार : 2000</p>\n    </ion-item>\n    <ion-item>\n      <ion-icon name=\"share-outline\">\n      </ion-icon>\n      <p>कुटूंब : 100</p>\n    </ion-item>\n  </ion-row>\n\n  </ion-card>\n</ion-content>");

/***/ }),

/***/ 1026:
/*!*********************************************************!*\
  !*** ./src/app/pages/village/village-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VillagePageRoutingModule": () => (/* binding */ VillagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _village__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./village */ 3953);




const routes = [
    {
        path: '',
        component: _village__WEBPACK_IMPORTED_MODULE_0__.VillagePage
    }
];
let VillagePageRoutingModule = class VillagePageRoutingModule {
};
VillagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], VillagePageRoutingModule);



/***/ }),

/***/ 65:
/*!*************************************************!*\
  !*** ./src/app/pages/village/village.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VillageModule": () => (/* binding */ VillageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8058);
/* harmony import */ var _village__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./village */ 3953);
/* harmony import */ var _village_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./village-routing.module */ 1026);







let VillageModule = class VillageModule {
};
VillageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _village_routing_module__WEBPACK_IMPORTED_MODULE_1__.VillagePageRoutingModule
        ],
        declarations: [
            _village__WEBPACK_IMPORTED_MODULE_0__.VillagePage,
        ]
    })
], VillageModule);



/***/ }),

/***/ 3953:
/*!******************************************!*\
  !*** ./src/app/pages/village/village.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VillagePage": () => (/* binding */ VillagePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 8111);
/* harmony import */ var _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_village_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@angular-devkit/build-angular/node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./village.html */ 9587);
/* harmony import */ var _village_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./village.scss */ 697);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 8058);






let VillagePage = class VillagePage {
    constructor(alertCtrl, toastCtrl, router, nav) {
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.router = router;
        this.nav = nav;
        this.submitted = false;
        this.todoList = [{
                itemName: "शिनारे वस्ती"
            }, {
                itemName: "ऊचाळे वस्ती (पूर्व )"
            }, {
                itemName: "ऊचाळे वस्ती (पश्चिम)"
            }, {
                itemName: "भिल्ल वस्ती"
            }, {
                itemName: "धनगर वस्ती"
            }, {
                itemName: "मधुकर नगर"
            }, {
                itemName: "भोसले वस्ती"
            }, {
                itemName: "कुरण वस्ती"
            }, {
                itemName: "नरसाळवाडी"
            }, {
                itemName: " खामकर वाडी"
            }, {
                itemName: "शेळकेवस्ती"
            }, {
                itemName: "कोल्हेवस्ती"
            }, {
                itemName: "खाडेवस्ती"
            }, {
                itemName: "गावठाण"
            }, {
                itemName: "भोरवस्ती"
            }, {
                itemName: "कानिफनाथ वस्ती"
            }, {
                itemName: "चौधरीमळा"
            }, {
                itemName: "चाटे वस्ती "
            }, {
                itemName: "इतर "
            }];
    }
    openKutumba(vastiName) {
        //this.router.navigateByUrl('/app/tabs/kutumba');
        let navigationExtras = {
            queryParams: {
                special: JSON.stringify({ vasti: vastiName })
            }
        };
        this.nav.navigateForward('/kutumba', { state: { vasti: vastiName } });
        // this.router.navigate(['/app/tabs/kutumba',navigationExtras]);
        // this.router.navigate(['/app/tabs/kutumba'], { state: { vasti: vastiName } });
    }
};
VillagePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ToastController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
VillagePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'page-village',
        template: _C_Software_Shirapur_node_modules_angular_devkit_build_angular_node_modules_ngtools_webpack_src_loaders_direct_resource_js_village_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_village_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], VillagePage);



/***/ }),

/***/ 697:
/*!********************************************!*\
  !*** ./src/app/pages/village/village.scss ***!
  \********************************************/
/***/ ((module) => {

module.exports = "ion-content ion-card {\n  --background:#F0F4FD;\n}\nion-content ion-item {\n  --background:#F0F4FD;\n}\nion-content p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZpbGxhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLG9CQUFBO0FBQUY7QUFFQTtFQUNFLG9CQUFBO0FBQUY7QUFHRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBREoiLCJmaWxlIjoidmlsbGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XG5pb24tY2FyZHtcbiAgLS1iYWNrZ3JvdW5kOiNGMEY0RkQ7XG59XG5pb24taXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiNGMEY0RkQ7XG59XG5cbiAgcHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XG4gICAgY29sb3I6ICM4YzhjOGM7XG4gICAgbWFyZ2luOjA7XG4gIH1cbn1cbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_village_village_module_ts.js.map